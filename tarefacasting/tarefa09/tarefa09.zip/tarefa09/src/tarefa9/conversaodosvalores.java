package tarefa9;

public class conversaodosvalores {
    public static void main (String args[]){
        int nota1 = 10;
        System.out.println(nota1);
        short nota2 = (short) nota1;
        System.out.println(nota2);


    }
}
