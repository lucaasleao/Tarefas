package tarefamod13;

public class PessoaFisica extends Pessoa{
    private float cpf;

    public float getCpf() {
        return cpf;
    }

    public void setCpf(float cpf) {
        this.cpf = cpf;
    }




}

