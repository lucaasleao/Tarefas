package tarefamod13;

public class PessoaJuridica extends Pessoa{
    private float cnpj;


    public float getCnpj() {
        return cnpj;
    }

    public void setCnpj(float cnpj) {
        this.cnpj = cnpj;
    }



}
